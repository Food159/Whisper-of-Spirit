using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PlayerAction
{
    Attack,
    Run,
    Jump,
    Dead,
    Hurt,
    Resume,
    Pause,
    ToggleCamTrack
}
